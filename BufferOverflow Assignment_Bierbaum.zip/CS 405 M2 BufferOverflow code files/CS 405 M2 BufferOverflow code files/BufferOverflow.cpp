// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  //using getline to read input so we can stop read the number of characters specified by the user_input buffer size
  std::cin.getline(user_input, sizeof(user_input));

  //check to see if the input was too long
  if (std::cin.fail()) {
      //clear out the error state
      std::cin.clear();
	  //clear out the rest of the data in the input buffer
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	  //notify the user and exit
      std::cout << "Error: Input is too long. Please enter no more than 19 characters." << std::endl;
      return 1;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
